ShipManifest - Contributors
=============================

*Ship Manifest* was originally written by **Papa_Joe** and was partially based on *Crew Manifest v0.5.6.0* by **xxSovereignxx**.

The following is an incomplete list of contributors to *Ship Manifest*.

Please contact the current maintainer if somoene has been left off this list.

 - **arivaldh**
   - bug fixes and compatibility with Kopernicus and RemoteTech
 - **JPLRepo**
   - initial version of SMWrapper.cs
 - **Matt Addison**
   - ToolbarWrapper integration
 - **@Micha**
   - current maintainer
 - **@Papa_Joe** aka **@PapaJoesSoup** aka **Joseph Korinek**
   - original author
   - original design, development, and release
 - **@Sarbian*
   - contributions to "Crew Manifest" from which this mod was derived
 - **vXSovereignXv**
   - author of "Crew Manifest" from which this mod was derived
 - **Telanor**
   - Improved science handling via IScienceDataContainer
